
Customization metacity theme (dark)
------------------------------------
two files are copied (metacity-theme-1.xml and metacity-theme-3.xml)
if you want you can make a backup, before doing anything

Copy the contents of the file "metacity-cupertino-dark.tar.gz" in folder .. /Gnome-Cupertino/metacity-1/

logout and login, .. and ready :)

The base color is #383838 but if you want another, just edit (search and replace) the files metacity-theme-1.xml and metacity-theme-3.xml, can change the values ​​for the one you like




